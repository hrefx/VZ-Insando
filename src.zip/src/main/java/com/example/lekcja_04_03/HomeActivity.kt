package com.example.lekcja_04_03

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore

class HomeActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        auth = Firebase.auth

        val currentUser = auth.currentUser

        val db = Firebase.firestore

        val logOut:Button=findViewById(R.id.logOutButton)
        val addOutfit:Button=findViewById(R.id.addOutfitButton)
        val docref=db.collection("insandoApp").document(currentUser!!.uid)
        val nameUser:TextView=findViewById(R.id.textViewNameUserHome)
        val posts = mutableListOf<Post>()
        val recycler:RecyclerView=findViewById(R.id.recyclerView)

        val adapter = PostAdapter(posts)
        recycler.adapter = adapter
        recycler.layoutManager = LinearLayoutManager(this)

        logOut.setOnClickListener {
            auth.signOut()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
        db.collection("insandoAppPosts")
            .get()
            .addOnSuccessListener { result ->
                posts.clear()

                for (document in result) {
                    Log.d("Home", "${document.id} => ${document.data}")
                    posts.add(
                        Post(
                            document.id, document.getString("typeOfDress") ?: "", document.getString("typeOfFit") ?: "", document.getString("price") ?: "",document.getString("imageURL") ?: ""
                        )
                    )
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.d("Home", "Error getting documents: ", exception)
            }
        addOutfit.setOnClickListener {
            val intent = Intent(this, AddPostActivity::class.java)
            startActivity(intent)
            finish()
        }
        if(currentUser!=null)
        {
            docref.get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        nameUser.text = document.data?.get("userName").toString()
                    } else {
                        Log.d(ContentValues.TAG, "No such document.")
                    }
                }
                .addOnFailureListener { exception->
                    Log.d(ContentValues.TAG,"get failed with ",exception)
                }
        }
        else{
            val intent=Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}