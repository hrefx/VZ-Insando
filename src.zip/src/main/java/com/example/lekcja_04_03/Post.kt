package com.example.lekcja_04_03

import android.widget.ImageView

data class Post(val postId : String, val typeOfDress : String, val typeOfFit : String, val price : String, val imageURL: String)
