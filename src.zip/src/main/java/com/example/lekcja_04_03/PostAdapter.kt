package com.example.lekcja_04_03

import android.content.Intent
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso;
import androidx.recyclerview.widget.RecyclerView

class PostAdapter (val posts: MutableList<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {
    inner class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post_image:ImageView=holder.itemView.findViewById(R.id.imageView)
        val dress: TextView = holder.itemView.findViewById(R.id.textView8)
        val fit: TextView = holder.itemView.findViewById(R.id.textView10)
        val price: TextView = holder.itemView.findViewById(R.id.textView11)

        dress.text = posts[position].typeOfDress
        fit.text = posts[position].typeOfFit
        price.text = posts[position].price
        val postImageUrl=posts[position].imageURL
        if(postImageUrl.isNotEmpty()){
            Picasso.get().load(postImageUrl).into(post_image)
        }

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, HomeActivity::class.java)
            intent.putExtra("postId", posts[position].postId)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return posts.size
    }
}