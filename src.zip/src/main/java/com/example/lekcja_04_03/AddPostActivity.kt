package com.example.lekcja_04_03

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

class AddPostActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var imageView: ImageView
    private var imageUri: Uri? = null

    private val getContent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if(it.resultCode == Activity.RESULT_OK)
        {
            val data: Intent? = it.data
            imageUri = data?.data
            imageView.setImageURI(imageUri)


        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_post)
        auth = Firebase.auth

        val currentUser = auth.currentUser
        val db = Firebase.firestore

        val addButton: Button=findViewById(R.id.addButton)
        val dress: EditText=findViewById(R.id.dressEditAdd)
        val fit: EditText=findViewById(R.id.fitEditAdd)
        val price: EditText=findViewById(R.id.priceEditAdd)

        imageView = findViewById(R.id.addImage)

        imageView.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            getContent.launch(intent)
        }
        addButton.setOnClickListener {
            val dress_text = dress.text.toString()
            val fit_text = fit.text.toString()
            val price_text = price.text.toString()
            val user = auth.currentUser
            val storageReference = FirebaseStorage.getInstance().reference
            val imageRef = storageReference.child("images/" + UUID.randomUUID().toString())
            val uploadTask = imageRef.putFile(imageUri!!)
            val db = Firebase.firestore

            uploadTask.addOnSuccessListener { taskSnapshot ->
                val downloadUrl = taskSnapshot.storage.downloadUrl.toString()
                Log.d("MAIN", downloadUrl)

                val newPost = hashMapOf(
                    "typeOfDress" to dress_text,
                    "typeOfFit" to fit_text,
                    "price" to price_text,
                    "imageURL" to downloadUrl
                )

                db.collection("insandoAppPosts")
                    .add(newPost)
                    .addOnSuccessListener {
                        Log.d("TAG", "DocumentSnapshot successfully written!")
                        val intent = Intent(this, HomeActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }

            }.addOnFailureListener {
                Log.d("MAIN", "error")
            }


        }
    }
}